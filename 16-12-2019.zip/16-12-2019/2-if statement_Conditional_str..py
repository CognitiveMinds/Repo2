Str1  = 'Bipin Behera'
Str2  = 'Bipin'
if Str1 > Str2:
    print('Smaller')
if Str2 < Str1:
    print('Bigger')
if Str2 < Str1:
    print("Last print")
print('Finish')
