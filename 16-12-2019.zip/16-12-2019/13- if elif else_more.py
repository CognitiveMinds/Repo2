x = 3
y = 7
z = 10

if x < y and x > z:
    print('something here was the case')
elif x > z:
    print(x,'is less than',z)
elif y < z:
    print(y,'is less than',z)
else:
    print('nothing was the case')

