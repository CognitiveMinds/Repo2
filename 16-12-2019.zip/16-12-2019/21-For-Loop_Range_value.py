# Syntax : range([start], stop, [step])
x = range(1,20,2) # number starting with -1 and excliding 5 will be printed.
for i in x:
    print(i)
