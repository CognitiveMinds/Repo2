x = 42
if x > 1 :
    print('More than one')
    if x > 100 :
        print('Less than 100')
print('All done')

