import itertools

# initializing list
li = [2, 4, 6, 7, 8, 10, 20]

# storing list in iterator
iti = iter(li)
print(list(iti))
it = itertools.tee(iti, 3)
print(list(it))
# printing the values of iterators
print ("The iterators are : ")
for i in range(0,3):
    print (list(it[i]))
