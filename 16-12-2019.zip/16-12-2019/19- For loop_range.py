
#exampleList = [1,6,7,3,6,9,0]

for thing in range(0,20,3):
    print(thing)

for x in range(1,11):
    print(x)

