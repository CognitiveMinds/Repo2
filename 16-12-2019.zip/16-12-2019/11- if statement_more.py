x = 2
y = 7
z = 10

if x > y:
    print(x,'is greater than',y)
if x < y:
    print(x,'is less than',y)
if x == y:
    print(x,'is the same as',y)
    
# cannot do this:
#if x < '2':
#    print(x,'is less than 2')

if x <= y:
    print(x,'is less than or equal to',y)

if z > y > x:
    print(z,'is greater than',y,'which is greater than',x)



    
