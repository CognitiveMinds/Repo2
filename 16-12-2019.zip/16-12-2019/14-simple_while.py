# Python program to illustrate
# while loop
count = 0
while (count < 3):
    count = count + 1
    print("Hello World!")
else:
    print("Loop Ends!")

