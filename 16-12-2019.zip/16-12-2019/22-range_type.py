# initializing a with range()
a = range(1,10000)

# python 2.7 initializing a with xrange()
#x = xrange(1,10000)

# testing the type of a
print ("The return type of range() is : ")
print (type(a))

# python 2.7 testing the type of x
print ("The return type of xrange() is : ")
for i in a:
    print(i)
