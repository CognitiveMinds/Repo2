
condition = 1

while condition < 10:
    print(condition),
    
    ''' multiple lines can go here '''
    
    #condition = condition + 1
    condition += 1
"""multiple lines can go here hjgjhvsdgjbbbbbdsbkjnbbbbbbbbbbbbbvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
kllkjlkjkljlkf
kjhjkvdshkjvhdkjhdsf
bhjhvsdhgjdsjhg"""


a = [1,2,4,6]

for i in range(0,4):
    print(a[i]," ",end="")
print("\n")
#condition = 5

#while condition < 15:
#    print('True')

#while True:
    #print('infinite')#


a,b = 0,1
while a < 10:
    print(a," ",end="")
    a,b=b,a+b












    
