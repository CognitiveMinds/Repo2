# Enemuration Looping
student_DB = enumerate([78,92,85,87,69,45])
for value in student_DB:
    print(value)

