x = 4
if x > 2 :
    print('Bigger')
else :
    print('Smaller')
print('All done')
