# working with enumerate()
for key,value in enumerate(['The', 'Big', 'Bang', 'Theory']):
    print( key ,value)
# if key will not be given then key value pair will be printed like (0,'The')..
for  value in enumerate([1,4,8,10,40]):
    print( value)
# Here key has not given only value request in the loop , python will print both key ad its value
# in oder (0,1),2,4),(3,8) so on and so forth..
#---------------------------------------#-------------------------------
# python code to demonstrate working of zip()

# initializing list
questions = ['name', 'colour', 'shape']
answers = ['apple', 'red', 'a circle']

# using zip() to combine two containers
# and print values
# value will be printed as index value of {} , 0 is for first , 1 for 2nd and 2 for 3rd so on..
for question, answer in zip(questions, answers):
    print('What is your {0}?  I am {1} .'.format(question,answer))


#=======================================================================#

d = { "India" : "New Delhi", "Pak" : "Islamabad" }
# using items to print the dictionary key-value pair
print ("The key value pair using items is : ")
for i,j in d.items():
    print(i,":",j)

# more examples

king = {'Akbar': 'The Great', 'Chandragupta': 'The Maurya',
        'Modi' : 'The Changer'}

# using items to print the dictionary key-value pair
for key, value in king.items():
    print(key, value)
#***************************************************************************#

# initializing list
list = [ 1 , 3, 5, 6, 2, 1, 3 ]

# using sorted() to print the list in sorted order
print ("The list in sorted in asc order : ")
for i in sorted(list) :
    print (i,end=" ")

print ("\r")

# using sorted() and set() to print the list in sorted order
# use of set() removes duplicates.
print ("The list in sorted order (without duplicates) is : ")
for i in sorted(set(list)) :
    print (i,end=" ")

print ("\r")
# python code to demonstrate working of sorted()

# initializing list
basket = ['guave', 'orange', 'apple', 'pear',
          'guava', 'banana', 'grape']

# using sorted() and set() to print the list
#  in sorted order
for fruit in sorted(set(basket)):
    print(fruit)


# python code to demonstrate working of reversed()

# initializing list
lis = [ 1 , 3, 5, 6, 2, 1, 3 ]



# using revered() to print the list in reversed order
print ("The list in reversed order is : ")
for i in reversed(lis):
    print (i,end=" ")
print ("\r")
# we xan add sorted to gett list in sequence


# python code to demonstrate working of reversed()

# using reversed() to print in reverse order
for i in reversed(range(1, 20, 3)):
    print (i)
#-------------------------------------------------------------
# python 2.7 code to demonstrate working of iteritems(),items()
d = { "key1" : "Value1", "key2" : "value2","key3": "value3" }
# using iteritems to print the dictionary key-value pair
print ("The key value pair using iteritems is : ")
for i,j in d.iteritems(): # this function is part of python 2.7
    print(i,j)
