n = 5
    # number of spaces
k = 2*n - 2
for i in range(n):
    print(end=" "*k)
    k = k - 2
    for j in range(1,i+1):
        print(j, end=' ')
    print()


data = 'Indian Constituitions'
for d in data:
    if d=='i' or d=='o' or d=='n': # if it is true then move to else
        pass
    else:
        print ("Letters is {} ".format(d), end=" ")


num=0
while num<5:
    num=num+1
    print ("Num =  {} ".format(num))
    if num==3: # if true then stop and pick the next number
        break
print ("Out of loop")
