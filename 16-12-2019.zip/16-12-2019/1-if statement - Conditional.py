x = 5
if x < 10:
    print('Smaller')
if x > 20:
    print('Bigger')

print('Finish')
