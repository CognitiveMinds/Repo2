def myGenerator(x):
    for i in range(x):
        print('First item')
        yield 10


        print('Second item')
        yield 20

        print('Last item')
        yield 30

gen = myGenerator(5)
next(gen)
next(gen)
next(gen)
