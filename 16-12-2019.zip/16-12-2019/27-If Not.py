list1=[1,2,3,4,5]
list2=[5,7,8,9]
for item in list1:
    if item in list2:
        print("overlapping")
else:
    print("not overlapping")
