x = 13
y = 6

if x < y:
    print(x,'is less than',y)
if x > y:
    print(x,'is greater than',y)
else:
    print(x,'is not less than',y)
